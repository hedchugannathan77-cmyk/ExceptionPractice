package service;

import exception.DuplicateRecordException;
import model.ItemRecord;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Stores records and enforces unique Record IDs.
 */
public class RecordManager {
    private final List<ItemRecord> records = new ArrayList<>();

    public void addRecord(ItemRecord record) throws DuplicateRecordException {
        if (record == null) {
            throw new IllegalArgumentException("Record cannot be null.");
        }

        if (findRecord(record.getRecordId()) != null) {
            throw new DuplicateRecordException(
                "Record ID " + record.getRecordId() + " already exists."
            );
        }

        // Add only after all validation checks pass.
        records.add(record);
    }

    public ItemRecord findRecord(String recordId) {
        if (recordId == null) {
            return null;
        }

        for (ItemRecord record : records) {
            if (record.getRecordId().equalsIgnoreCase(recordId.trim())) {
                return record;
            }
        }
        return null;
    }

    public List<ItemRecord> getAllRecords() {
        return Collections.unmodifiableList(records);
    }

    public boolean hasRecords() {
        return !records.isEmpty();
    }
}
