package app;

import exception.DuplicateRecordException;
import model.ItemRecord;
import service.RecordManager;

import java.util.Scanner;

/**
 * Console application demonstrating exception handling,
 * input validation, custom exceptions, and safe recovery.
 */
public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final RecordManager manager = new RecordManager();

    public static void main(String[] args) {
        boolean running = true;

        System.out.println("==================================");
        System.out.println("     EXCEPTION-SAFE RECORDS");
        System.out.println("==================================");

        while (running) {
            System.out.println("\n1. Add Record");
            System.out.println("2. View Accepted Records");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    addRecord();
                    break;
                case "2":
                    displayRecords();
                    break;
                case "3":
                    running = false;
                    System.out.println("Program closed safely. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid menu choice. Please enter 1, 2, or 3.");
            }
        }

        scanner.close();
    }

    private static void addRecord() {
        try {
            System.out.print("Enter Record ID: ");
            String id = scanner.nextLine();

            if (id.trim().isEmpty()) {
                throw new IllegalArgumentException("Record ID cannot be blank.");
            }

            System.out.print("Enter Item Name: ");
            String name = scanner.nextLine();

            if (name.trim().isEmpty()) {
                throw new IllegalArgumentException("Item name cannot be blank.");
            }

            System.out.print("Enter Quantity: ");
            String quantityInput = scanner.nextLine().trim();

            int quantity;
            try {
                quantity = Integer.parseInt(quantityInput);
            } catch (NumberFormatException e) {
                System.out.println("Invalid quantity: enter a whole number.");
                return;
            }

            ItemRecord record = new ItemRecord(id, name, quantity);
            manager.addRecord(record);

            System.out.println("SUCCESS: Record added successfully.");

        } catch (DuplicateRecordException e) {
            System.out.println("DUPLICATE RECORD: " + e.getMessage());
            System.out.println("The original record was preserved.");

        } catch (IllegalArgumentException e) {
            System.out.println("INPUT ERROR: " + e.getMessage());
            System.out.println("Please try again. The program is still running.");

        } catch (Exception e) {
            System.out.println("UNEXPECTED ERROR: " + e.getMessage());
            System.out.println("The program will continue running.");
        }
    }

    private static void displayRecords() {
        System.out.println("\n========== ACCEPTED RECORDS ==========");

        if (!manager.hasRecords()) {
            System.out.println("No accepted records yet.");
            return;
        }

        System.out.printf("%-12s %-22s %s%n", "Record ID", "Item Name", "Quantity");
        System.out.println("----------------------------------------------");

        for (ItemRecord record : manager.getAllRecords()) {
            System.out.println(record);
        }
    }
}
