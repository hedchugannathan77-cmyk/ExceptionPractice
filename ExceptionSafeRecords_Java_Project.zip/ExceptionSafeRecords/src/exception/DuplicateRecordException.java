package exception;

/**
 * Custom checked exception thrown when a Record ID already exists.
 */
public class DuplicateRecordException extends Exception {
    public DuplicateRecordException(String message) {
        super(message);
    }
}
