EXCEPTION-SAFE RECORDS
Java Console Application

FEATURES
1. Exception handling with try-catch.
2. Input validation for blank IDs and names.
3. Integer validation for quantity.
4. Positive quantity requirement.
5. Custom DuplicateRecordException.
6. Safe recovery: the menu remains available after invalid input.
7. Only accepted records are displayed.

PROJECT PACKAGES
src/app/Main.java
src/model/ItemRecord.java
src/service/RecordManager.java
src/exception/DuplicateRecordException.java

HOW TO RUN
1. Open the project in NetBeans, IntelliJ IDEA, or Eclipse.
2. Make sure the four package folders match the package declarations.
3. Run app.Main.
4. Choose 1 to add a record, 2 to view records, or 3 to exit.

TESTING NOTE
To test duplicate detection, first add a valid record with ID R001.
Then try adding another record with ID R001.
The duplicate must be rejected and the original record must remain unchanged.

EXAMPLE TESTS
- Blank Record ID: rejected.
- Blank Item Name: rejected.
- Non-numeric quantity: rejected without crashing.
- Quantity 0 or negative: rejected.
- Valid R001: accepted.
- Duplicate R001: rejected; original preserved.
- Add another valid record after an error: accepted.
- View records: accepted records only.
